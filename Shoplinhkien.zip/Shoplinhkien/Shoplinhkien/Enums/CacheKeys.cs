﻿using System;
using Shoplinhkien.Models;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Shoplinhkien.Enums
{
    public enum CacheKeys
    {
        Categories
    }
}
